# @hokusai/core

The harness-agnostic contracts behind the Hokusai router: the API client, the
routing payload and dispatch builder, redaction and consent, the model registry,
and the contribution rows the router learns from.

**Most integrations should not start here.** If you are routing tasks from
application code, use [`@hokusai/router`](../router) — a thin façade over this
package that owns the wiring the common case should not have to think about:

```sh
npm install @hokusai/router
```

Reach for `@hokusai/core` when you are building a harness: when you need custom
consent scopes, your own redaction config, control over correlation storage, or
the raw request and response shapes.

## Install

```sh
npm install @hokusai/core
```

## The loop

Every integration is the same three steps. Route a task, run it yourself, then
contribute the outcome — the contribution is what trains the router.

```ts
import {
  HokusaiClient,
  HokusaiDispatchBuilder,
  InMemoryModelRegistry,
  ANTHROPIC_MODELS,
  SDK_VERSION,
  buildTechnicalTaskRouterRowV4,
  deriveTaskDescriptor,
} from '@hokusai/core';
import { measureTask } from '@hokusai/costs';

const client = new HokusaiClient({ apiKey: process.env.HOKUSAI_API_KEY });
const registry = new InMemoryModelRegistry(ANTHROPIC_MODELS);

const builder = new HokusaiDispatchBuilder({
  consent: {
    subjectId: 'my-harness',
    grantedScopes: ['task-execution', 'telemetry'],
  },
  modelRegistry: registry,
});

// 1. Route. The prompt is redacted before it leaves the process.
const payload = await builder.prepareDispatch(
  task,
  registry.getDefault()!.id,
  'task-execution',
  {
    availableModels: ['claude-sonnet-4-6', 'claude-opus-4-8'],
    objective: 'highest_reliability',
    maxCostUsd: 1,
  },
);
const decision = await client.route(payload);

// 2. Run the model yourself, measuring it. Hokusai never calls a model.
const model = decision.recommendation.model;
const { cost } = await measureTask({ taskId: task.id }, async (tracker) => {
  const response = await runYourModel(model, task); // your code
  tracker.recordUsage({ model, usage: response.usage }); // tokens, per call
});

// 3. Contribute the outcome, attributed to the decision it came from.
const row = buildTechnicalTaskRouterRowV4({
  taskId: task.id,
  inferenceLogId: decision.routeId, // without this the row is unattributable
  routeOverrides: [], // the recommendation was run as given
  taskDescriptor: deriveTaskDescriptor({ taskText: task.prompt }),
  allowedModels: ['claude-sonnet-4-6', 'claude-opus-4-8'],
  selectedModels: { coder: model, reviewer: model },
  observedSuccess: true,
  budgetCompliant: (cost.totalUsd ?? Infinity) <= 1,
  budgetUsd: 1,
  observedAt: new Date().toISOString(),
  sdkVersion: SDK_VERSION,
  // One entry per stage that ran; each stage's cost is its @hokusai/costs report.
  stageExecutions: [
    { stage: 'coding', executedModel: model, modelEvidence: 'provider_response', harness: 'my-harness', cost },
  ],
});

const response = await client.submitContribution({
  rows: [row],
  metadata: { idempotency_key: task.id },
});
response.rowFidelityTiers; // ['training_eligible']
```

## Contribute, don't report

`client.reportOutcome()` and `POST /api/v1/outcomes` still exist as a
telemetry/compatibility surface. They patch an inference log and **bypass
training and reward attribution entirely. Do not build a new integration on
them.** Use `submitContribution()`.

The server classifies every accepted row and returns a **fidelity tier**. Only
`training_eligible` trains the router or earns rewards. Reaching it requires a
non-empty task descriptor, a non-empty `allowedModels`, `selectedModels` naming a
coder or reviewer, an `inferenceLogId`, and **both** `budgetUsd` and
`actualCostUsd` — the server scores the cost against the budget, and cannot score
a row missing either. A `partial` row is still `accepted: true`, so the tier is
the only signal that a contribution counted. It is server-authoritative: read it,
never compute it.

## Routing outcomes: `inference_log_id` and overrides

`technical_task_router_row/v3` and `harness_outcome_row/v2` share one
routing-outcome block (HOK-3364), which is how Model 30 learns whether its
recommendation was right:

- `inference_log_id`: the inference that made the recommendation (the route's
  `routeId`). Present iff Hokusai routed the task.
- `overrides`: present iff `inference_log_id` is. Each entry is
  `{ role, source: escalation | launchability | challenge | operator | observed, from, to, reason }`
  (`observed`: the harness's session record shows another model ran),
  chained per role and ending at the executed model. `[]` means the
  recommendation was followed.
- `selected_models`: the executed models.

Rows never store a copy of the recommendation (`recommended_model`,
`recommendation_accepted`, …); validation rejects one. Hokusai joins the
recommendation from its inference log, and "accepted" is derived
(`routeRecommendationFollowed(row, role)`). Builders take `inferenceLogId` and
`routeOverrides` and have no default: a routed row without explicit
`routeOverrides` throws, so a harness can never claim the recommendation was
followed by omission. v1/v2 harness rows and v1–v3 router rows stay accepted;
new writers emit router v4 (below). Golden rows: `routingOutcomeFixtures`.

## Per-stage execution facts: `technical_task_router_row/v4`

v4 (HOK-3412) is v3 plus the facts Model 30 trains on per role:

- `stage_executions[]`: one entry per stage that ran, in run order. `stage` is
  `planning | coding | review` (mapped to `planner | coder | reviewer`) or a repair
  stage: `ci-fix | conflict-resolution | ready-remediation`. Each entry has the
  `executed_model`, `model_evidence` (`provider_response | session_telemetry |
  requested_only`), the `harness` slug, and a `task_cost`: the
  `task_cost_summary/v1` over that stage's sessions, with tokens per model and
  coverage, pricing source and join confidence.
- `task_cost` is **required**. Pass each stage's `@hokusai/costs` report
  (`measureTask` / `tracker.summary()`) as its `cost`, and
  `buildTechnicalTaskRouterRowV4` does all the token handling. An empty report
  becomes an explicit `coverage: 'unavailable'` summary
  (`unavailableTaskCostSummary`). A report that spans several harnesses
  must be split into one stage per harness.
- The last entry for each base stage must name the matching `selected_models`
  role. Repair stages are not tied to a role.
- `comparison_group` (optional): `{ id, role_varied }` for runs of the same task
  on different routes. `id` is the minted `pair_id` of the task-attempt
  contract.
- `integration` is reserved for HOK-3343; only `{}` is accepted.
- `sdk_version` (optional): the SDK that wrote the row.
- `actual_cost_usd` is **contributor-reported evidence**. Hokusai reprices the
  row from `stage_executions[].task_cost`. When you omit it and every stage's
  cost resolved, the builder fills in their sum.

Privacy: each `task_cost` also passes the task-cost contract's stricter
forbidden-key list (paths, repo, branch, credentials, identity), so a row holds
model ids, opaque session and event ids and token counts — never prompts or
paths.

The Claude Code and Codex plugins measure the route's own session.
`createRunReportCli` and `submitOutcomeCommand` take a `MeasureStage`, and the
adapters supply one built on `@hokusai/costs`, so core never parses provider
session files. Golden rows: `contributionV4Fixtures`, with
`contributionV4StageSources` naming each stage's task-cost fixture. The
field contract for non-TypeScript writers is exported by `pnpm export:schemas`.

## External observations

Externally chosen runs should still use `submitContribution()`, but they should
not fabricate an `inferenceLogId`. Build a v4 row with no `inferenceLogId` and
no `routeOverrides` (an unrouted row) and the observed task descriptor,
candidate pool, selected model, budget and measured stage cost, then read the
server-assigned fidelity tier:

```ts
const row = buildTechnicalTaskRouterRowV4({
  taskId: 'external-run-123',
  taskDescriptor: deriveTaskDescriptor({ taskText }),
  allowedModels: ['qwen-3-coder', 'glm-5.2', 'gemini-2.5-pro'],
  selectedModels: { coder: 'qwen-3-coder', reviewer: 'qwen-3-coder' },
  observedSuccess: true,
  budgetCompliant: true,
  budgetUsd: 0.5,
  observedAt: new Date().toISOString(),
  harness: 'custom-harness',
  stageExecutions: [
    { stage: 'coding', executedModel: 'qwen-3-coder', modelEvidence: 'requested_only', harness: 'custom-harness', cost },
  ],
});

const response = await client.submitContribution({
  rows: [row],
  metadata: { idempotency_key: 'external-run-123' },
});
```

Use `@hokusai/router`'s `route.reportExternalOutcome()` helper when you want
this report-only path without manually building rows.

## Task-cost contract

**Requires `@hokusai/core` ≥ 0.5.0.** None of the following exists in 0.4.0.
Importing it there fails with `does not provide an export named
'aggregateTaskCost'`.

`@hokusai/core` exports the versioned task-cost contract (`task_cost_*/v1`,
`TASK_COST_CONTRACT_VERSION` `1.0.0`). It contains types, validators, and one
pure reducer:

- **Reducers:** `aggregateTaskCost`, `aggregateTaskCostByModel`
- **Validators:** `validateTaskCostEventV1`, `validateTaskCostSummaryV1`,
  `validateTaskCostLedgerV1`, the `isTaskCost*V1` guards, and
  `TaskCostValidationError`
- **Versions:** `TASK_COST_CONTRACT_VERSION`, `TASK_COST_EVENT_SCHEMA_VERSION`,
  `TASK_COST_SUMMARY_SCHEMA_VERSION`, `TASK_COST_LEDGER_SCHEMA_VERSION`,
  `TASK_COST_ADAPTER_CONTRACT_VERSION`, `PROVIDER_CONTRACT_VERSIONS`
- **Enums and types:** the `TASK_COST_*` value lists, plus `TaskCostEventV1`,
  `TaskCostSummaryV1`, `TaskCostLedgerV1`, and `TaskCostAdapterV1`
- **Attempt identity** (contract `1.1.0`, core ≥ 0.6.0): `task_attempt/v1`
  records, `reduceTaskAttemptLog`, `taskAttemptFixtures`
- **Queue, CI and repair lifecycle events** (contract `1.2.0`, core ≥ 0.7.0):
  `queue_lifecycle_event/v1` (`QueueLifecycleEventV1`,
  `validateQueueLifecycleEventV1`, `reduceQueueLifecycleLog`,
  `queueLifecycleFixtures`, `QUEUE_LIFECYCLE_EVENT_V1_JSON_SCHEMA`)

To measure a task rather than reduce events yourself, use
[`@hokusai/costs`](https://www.npmjs.com/package/@hokusai/costs).
`@hokusai/costs` pins `@hokusai/core` to its **exact** version. If you also
depend on core directly, use that same version. Otherwise you get two copies
of core, or keep running an older one.

A host that loads task-cost lazily can feature-detect it:

```ts
const core = await import('@hokusai/core');
if (!('aggregateTaskCost' in core)) {
  throw new Error('task-cost requires @hokusai/core >= 0.5.0');
}
```

The full contract (records, reducer rules, missing vs zero, and compatibility
rules) is in the
[task-cost contract README](https://github.com/Hokusai-protocol/hokusai-sdk/blob/main/packages/core/src/task-cost/README.md).
The version mapping is in the
[versioning policy](https://github.com/Hokusai-protocol/hokusai-sdk/blob/main/docs/versioning-policy.md#task-cost-contract-versions).

## Attaching cost to a contribution row

Where does `actualCostUsd` come from? For multi-turn or multi-model work —
or when you want per-model attribution, coverage, and pricing provenance —
measure the task with [`@hokusai/costs`](../costs/README.md)
(`measureTask` / `createTaskCostTracker`) and bridge
`cost.totalUsd ?? undefined` into the contribution (a `null` partial total is
passed as absent, never `0`). For a single best-effort number from one
session, `resolveActualCostUsd()` below remains the shared entry point and is
unchanged:

```ts
import { resolveActualCostUsd } from '@hokusai/core';

const measured = resolveActualCostUsd({
  model: 'openrouter/anthropic/claude-sonnet-4.6',
  explicitActualCostUsd: 0.1234,
});

const derived = resolveActualCostUsd({
  model: 'litellm/google/gemini-2.5-pro',
  inputTokens: 12_345,
  outputTokens: 678,
});
```

When the host exposes a measured cost, prefer `explicitActualCostUsd`. When it
does not, pass `inputTokens`, `outputTokens`, and the resolved model id so the
SDK can try token-derived fallback pricing.

Unknown or malformed model ids resolve to `undefined`, not a fabricated cost. In
that case the contribution row simply omits `actual_cost_usd` and remains
telemetry-only.

Model id normalization accepts:

- Bare ids such as `gpt-4o`, `gpt-5-codex`, `claude-sonnet-4-6`, and `gemini-2.5-pro`
- Provider-prefixed ids such as `openai/gpt-4o`, `anthropic/claude-sonnet-4.6`, and `google/gemini-2.0-flash-001`
- Nested OpenRouter/LiteLLM ids such as `openrouter/anthropic/claude-sonnet-4.6` and `litellm/google/gemini-2.5-pro`
- Dated snapshots such as `claude-haiku-4.5-20251001` and `gpt-4o-2024-08-06`

Known stripped prefixes are `openrouter/`, `litellm/`, `openai/`, `anthropic/`,
`google/`, `gemini/`, `deepseek/`, `meta-llama/`, `meta/`, `mistralai/`,
`moonshotai/`, `qwen/`, `x-ai/`, and `z-ai/`. Unknown prefixes are preserved on
purpose so unrelated vendor ids cannot accidentally collide with a priced model.

OpenAI rows carry their own cached-input rates and a long-context tier (more
than 272K input tokens), taken from the pricing page (Standard tier,
`OPENAI_MODEL_PRICING_AS_OF`). The long-context tier applies only when
`computeActualCostUsd` is told the counts are one request (`requestScoped`).
Anthropic uses the prompt-cache multipliers. Cache tokens with no rate in the
table (Gemini, OpenAI pro models, TTL-dependent gpt-6 / gpt-5.6 cache writes)
leave the cost `undefined`, never guessed.

## What leaves your process

Nothing you did not ask to send. Prompts are redacted before dispatch, task text
is reduced to categorical labels by `deriveTaskDescriptor`, and the API key is
structurally un-persistable — the config stores throw if you try to write it.
Outcome submission is off until explicitly enabled. See
[Privacy Model](../../docs/privacy-model.md).

## Arbiter candidate features

`candidate_features/v1` is the shared, derived-only contract used by Arbiter
producers and consumers. Build a vector from whichever projections are
available; the finalizer supplies every missing field as `null` and stamps the
schema version.

```ts
import {
  finalizeCandidateFeaturesV1,
  taskDescriptorToCandidateIntent,
  validateCandidateFeaturesV1,
  deriveTaskDescriptor,
} from '@hokusai/core';

const intent = taskDescriptorToCandidateIntent(
  deriveTaskDescriptor({
    taskText: task.prompt,
    repositorySignals: { fileCount: 420, extensionCounts: { ts: 180 } },
  }),
);

const features = finalizeCandidateFeaturesV1(
  { files_touched: 4, lines_added: 80, lines_deleted: 12, loc_touched: 92 },
  { type_errors: 0, lint_errors: 0, build_ok: true },
  intent,
);

const validation = validateCandidateFeaturesV1(features);
if (!validation.ok) throw new Error(JSON.stringify(validation.errors));
```

Zero and `false` mean a producer ran and observed those values. `null` means
the documented evidence was unavailable. Producers must never substitute a
default value for unavailable evidence.

## Documentation

- [SDK Overview](../../docs/sdk-overview.md) — the full public API surface
- [Integration Guide](../../docs/integration-guide.md) — building a new harness adapter
- [Reference Pattern](../../docs/reference-pattern.md) — the route → execute → contribute loop
- [Payload Schemas](../../docs/payload-schemas.md) — the wire contracts
- [`examples/reference-harness`](../../examples/reference-harness) — the smallest complete integration
